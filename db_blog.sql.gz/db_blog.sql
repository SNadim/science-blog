-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Mar 02, 2022 at 03:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cat`
--

CREATE TABLE `tbl_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cat`
--

INSERT INTO `tbl_cat` (`id`, `name`) VALUES
(1, 'Biology and Life Sciences'),
(2, 'Health, Medicine, and Veterinary Science'),
(3, 'Technology and Engineering'),
(4, 'Physics and Astronomy'),
(7, 'Chemistry'),
(9, 'Life & Non-Humans');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('approved','pending') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat_id`, `title`, `description`, `image`, `author`, `tags`, `date`, `status`) VALUES
(1, 1, 'Review of the Genetic Variability in Maize Genotypes (Zea mays L)', 'Maize (Zea mays L.) is the world\'s third most important cereal crop, with a high yield potential. Most authorities believe that Central America and Mexico, where many different species of maize can be found, are the primary sources of maize. It is one of the world\'s most important economic crops. Maize is a priority and strategic crop to react to the world\'s need for alternate energy sources, in addition to its usage as food and feed. It is the staple crop for millions of people in Ethiopia, where it ranks #1 in total output and yield per unit area. The genetic heterogeneity in the existing germplasm is used to select for high yield with desirable features. In order to be successful, breeding programs must have enough genetic variation to allow for selection and improvement. Knowing the extent of genetic variability, heritability, and genetic gains in the selection of desirable traits could aid the plant breeder in determining breeding program requirements. Many researches on genetic variability have been conducted using appropriate biometrical instruments such as variability, heritability, and genetic progress to determine the level of genetic diversity in the population. Genetic advance aids in crop development via selecting for specific features, and heritability is a useful measure for estimating the amount of the genetic portion of overall variability. The purpose of this review study was to evaluate the genetic variability, heritability, and genetic progress of maize genotypes.', 'postsimages/image1.png', 'WerkissaYali', 'Plant, Biology and Life sciences', '2022-01-27 09:26:07', 'approved'),
(9, 4, 'James Webb Space Telescope: 21st century universe', 'James Webb Space Telescope is the most powerful man-made telescope. Telescope was first invented four hundred years ago. In 1608, Dutch scientist Hans Lipperhey, also known as Johann Lippershey, discovered the first telescope. Galileo improved John\'s telescope in 1609. Some say James Webb telescope as JWST in a concise way. Installing the James Webb telescope into space started on 25th December last year. Earlier in 1990, the Hubble Telescope, built by the NASA and European Space Agency, was less powerful than the James Webb telescope.\r\n\r\nThe Hubble telescope, built in a seven-foot ten-inch mirror named by American scientist and astronomer Hubble thirty years ago, although it is still sending data. A more substantial mirror than Hubble, the James Telescope was built with the advantage mirror.\r\n\r\nJames Webb Telescope is a kind of space telescope. Lehman Spitzer gave the first current space telescope concept in 1946. However, the idea of a space telescope came first to scientists in 1923. The first space telescope was Orbiting Astronomical Observatory 2 or OAO-2. That was sent to space in 1968. The United States made it. The James Webb Space Telescope name has been taken to commemorate NASA\'s director from 1961 to 1968 James Webb. He died in 1992.', 'postsimages/989444-james-webb-telescope-090122-01.jpg', 'prince', 'Physics and Astronomy', '2022-01-30 06:52:33', 'approved'),
(19, 2, 'Omicron causes spike in COVID-19 cases in Bangladesh', 'As the omicron variant triggered a spike in infections, Bangladesh recorded 34 new coronavirus deaths, the highest in four months, according to the country’s Health Ministry on Sunday.\r\n\r\nSpeaking at a news conference in the capital Dhaka on Sunday, Bangladesh Health Minister Zahid Maleque said the real picture is grimmer than the official data, adding more infections and casualties would be reported if more people are tested.\r\n\r\nBangladesh reported 12,183 fresh cases on Sunday, taking the caseload to 1.78 million and the total fatalities to 28,363. The daily positivity rate was 28.33%, according to the Directorate General of Health Services (DGHS).', 'postsimages/331647-covid19.jpg', 'nadim', 'Health, Medicine, and Veterinary Science', '2022-02-13 07:20:46', 'approved'),
(56, 7, 'American Chemical Society’s analysis of diversity in its journals confirms an ‘imbalance’', 'The American Chemical Society’s (ACS) first-ever diversity report on its authors, reviewers, editors and editorial advisory board (EAB) members shows some significant but not unexpected disparities. The organisation said it will use this benchmark data to implement changes that can address systemic issues in peer review, editor selection, accessibility and other factors affecting diversity in scientific publishing.\r\n\r\nThe ACS undertook a demographic survey last year that informed the new report and found that men make up the majority of these categories, often by at least two-to-one. ‘The imbalance between the number of men and women in each stakeholder group is present at every stage of the publishing process for ACS publications journals,’ the report concludes. ‘Among all the authors, men have far greater representation than women or non-binary persons, in line with global trends on gender disparity in chemistry.’', 'postsimages/chemist-vector-742267-1645886444290.jpg', 'Admin', 'Chemistry', '2022-02-25 17:20:28', 'approved'),
(58, 9, 'Ancient cave deposits reveal our climate future', 'Every family has those stories that are passed down from generation to generation. Some of them have to do with history, others about a particular individual. But many of them have to do with the weather.\r\n\r\nWhether it be when the monsoons always arrive or what month brings the coldest weather, these stories contribute to society’s climate memory. ‘Because this information helps make climate predictable, it is very useful to, for example, a farmer planting crops,’ said Dr Sebastian Breitenbach, a palaeoclimatologist at Northumbria University.\r\n\r\nThe problem is that climate change is wreaking havoc on normal weather patterns, making our climate memory less reliable. ‘Historically, society can cope with a change in weather, such as a drought, that last just a couple of years,’ added Dr Breitenbach. ‘But when the disruption continues for too long, that’s when we tend to run into trouble.’\r\n\r\nTo avoid such trouble, society needs a climate memory that goes back not generations, but millennia.\r\n\r\nAnd getting that type of memory means going underground.\r\n\r\nOn a quantitative quest\r\n\r\nWhen it comes to accessing the Earth’s climate history, called paleoclimate information, caves have a lot to say.\r\n\r\nCaves are rich with deposits like stalactites and stalagmites. Called speleothems, these deposits are formed as water slowly makes its way down from the surface.\r\n\r\n‘Drip by drip, over the course of thousands, or even millions of years, these deposits grow, with each layer storing a record of their chemical composition,’ said Dr Breitenbach. ‘As a result, speleothems serve as excellent climate archives and are vital to understanding how climate varies and how the environment responds on seasonal to millennial timescales.’\r\n\r\nTo reconstruct past climate and environment, palaeoclimatologists use what are called proxy indicators, indirect measurements that allow them to detect variations in rainfall, vegetation, or extreme events like droughts.\r\n\r\nSo, what does this actually mean?\r\n\r\nTo find out, we asked Dr Breitenbach to explain: ‘Using proxies, I can tell you if 300,000 years ago the climate was warmer, colder, wetter or drier than today,’ he said. ‘What I can’t tell you is just how much warmer, colder, wetter or drier it was.’\r\n\r\nTo get this type of information, which is quantitative, Dr Breitenbach needs more complex proxies. Luckily, through the QUEST project, he’s helped develop a range of new proxies capable of extracting exactly this type of detailed information from speleothems.\r\n\r\nFor example, one of these new proxies looks at the specific chemical compounds that can be found in a cave deposit. ‘One of these compounds is only produced when a wildfire happens above the cave,’ remarked Dr Breitenbach. ‘When we find this compound in the speleothem, we can reconstruct when wildfires happened in the past, their severity, and their frequency.’\r\n\r\nDr Breitenbach and his team also developed proxies for identifying past changes in vegetation. ‘This type of quantitative information is crucial to making the speleothem record more useful to climate modellers and policy makers,’ he added.\r\n\r\nLooking to the past to predict the future\r\n\r\nDr Breitenbach isn’t alone in his quest to derive more detailed information from the speleothem record. In fact, similar research is happening in caves across the globe.\r\n\r\n‘Because reconstructing past climates is challenging, we are always looking for new, more reliable ways to extract information from geologic archives,’ said Anna Nele Meckler, a professor at the University of Bergen and a researcher with the FluidMICS project.\r\n\r\nProf Meckler is specifically interested in getting information about past temperatures from speleothems. That’s because, according to Prof. Meckler, having such information could teach us a lot about climate change and the impact that greenhouse gases have on our climate.\r\n\r\n‘We want to understand how sensitive temperature was to past changes in atmospheric CO2, how temperature changes in different regions were connected, and how quickly these responses happened,’ she said.\r\n\r\nTo get this information, Prof Meckler and her team are developing a process that can determine the density of small amounts of water found in the speleothems. ‘Because water density is linked to the temperature at the point in time when the water was trapped in the rock, it can tell us a lot about how hot or how cold it is was at a specific point in time,’ she added.\r\n\r\nExtending our climate memory\r\n\r\nAlthough each are working in different caves and in different parts of the world, all three researchers are working to extend our climate memory.\r\n\r\n‘As climate change is quickly moving us into unknown territory, we urgently need to better understand how today’s climate system might react,’ said Prof. Meckler. ‘At the very least, we can access past climate states and transitions and use this information to improve our ability to predict what lies ahead.’\r\n\r\n‘If we don’t know the past, how can we assess how vulnerable we are to the future,’ asks Dr Breitenbach? ‘With the right techniques, speleothems can shed light on this past, giving us a fighting chance to predict – and adapt to – what’s coming.’', 'postsimages/664844-fight-against-climate.jpg', 'Nadim21', 'Life & Non-Humans', '2022-03-01 08:28:55', 'approved'),
(59, 4, 'If a planet-killing asteroid threatens Earth, these astronomers have a plan', 'The popular Netflix movie Don’t Look Up is a satirical send up of two astronomers’ attempts to warn an indifferent world to the civilization-ending threat of an imminent asteroid impact. After its release, the film generated the most Netflix viewing hours in a single week.\r\n\r\nAt the heart of the movie is the question of what to do in the face of a threat from a 10-kilometer diameter asteroid heading straight towards us. That’s a similar size to the asteroid that that killed off the dinosaurs some 65 million years ago. If we had only 6 months warning, how could we save civilization?\r\n\r\nNow we have an answer thanks to the work of Philip Lubin and Alexander Cohen at the University of California, Santa Barbara, who have worked out how the world can defend itself in such a situation and in what circumstances this defense would be futile.', 'postsimages/873854-killerasteroid.jpg', 'rashik', 'Physics and Astronomy', '2022-03-01 14:01:21', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `email`, `password`, `picture`, `description`) VALUES
(1, 'Nadim', 'nadim21@gmail.com', '123456', 'userprofile/img_20220214_173457-1646123139289.jpg', 'Hello World'),
(8, 'prince', 'prince@gmail.com', '123456', 'userprofile/389981-prince.png', 'Hello I am a new user here!!'),
(11, 'Itachi', 'itachi@gmail.com', '123456', 'userprofile/632151-maxresdefault.jpg', 'If I had been open with you from the start… and looked you straight in the eyes and told you the truth, then I wouldn\'t have had to stand before you, from above, as a failure, telling you all of this. So this time, I want to impart this truth to you… You don\'t even have to forgive me. And no matter what you do from here on out, know this… I will love you always'),
(18, 'rashik', 'rashik@gmail.com', '123456', 'userprofile/62727-me.jpg', 'Hello I am a new user here!!');

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_CatId` (`cat_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `useremail` (`email`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD CONSTRAINT `FK_CatId` FOREIGN KEY (`cat_id`) REFERENCES `tbl_cat` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
